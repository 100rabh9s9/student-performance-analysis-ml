-- MySQL dump 10.16  Distrib 10.1.48-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.1.48-MariaDB-0+deb9u2

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Careapp_category`
--

DROP TABLE IF EXISTS `Careapp_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Careapp_category` (
  `id` tinyint(4) DEFAULT NULL,
  `category` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Careapp_category`
--

LOCK TABLES `Careapp_category` WRITE;
/*!40000 ALTER TABLE `Careapp_category` DISABLE KEYS */;
INSERT INTO `Careapp_category` VALUES (2,'Home Nurse'),(4,'Cleaning'),(5,'BabySitter');
/*!40000 ALTER TABLE `Careapp_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Careapp_chat`
--

DROP TABLE IF EXISTS `Careapp_chat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Careapp_chat` (
  `id` tinyint(4) DEFAULT NULL,
  `sender` varchar(15) DEFAULT NULL,
  `receiver` varchar(15) DEFAULT NULL,
  `date` varchar(26) DEFAULT NULL,
  `message` varchar(9) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Careapp_chat`
--

LOCK TABLES `Careapp_chat` WRITE;
/*!40000 ALTER TABLE `Careapp_chat` DISABLE KEYS */;
INSERT INTO `Careapp_chat` VALUES (1,'aswin@gmail.com','abru@gmail.com','2023-07-13 20:28:48.479654','Hello'),(2,'abru@gmail.com','aswin@gmail.com','2023-07-13 20:32:23.399633','hellooooo'),(3,'abru@gmail.com','aswin@gmail.com','2023-07-13 20:32:42.183444','hellooooo');
/*!40000 ALTER TABLE `Careapp_chat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Careapp_commission`
--

DROP TABLE IF EXISTS `Careapp_commission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Careapp_commission` (
  `id` tinyint(4) DEFAULT NULL,
  `date` varchar(0) DEFAULT NULL,
  `amt` decimal(4,1) DEFAULT NULL,
  `seid_id` tinyint(4) DEFAULT NULL,
  `uid_id` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Careapp_commission`
--

LOCK TABLES `Careapp_commission` WRITE;
/*!40000 ALTER TABLE `Careapp_commission` DISABLE KEYS */;
INSERT INTO `Careapp_commission` VALUES (1,'',120.0,2,1),(2,'',120.0,4,1);
/*!40000 ALTER TABLE `Careapp_commission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Careapp_customuser`
--

DROP TABLE IF EXISTS `Careapp_customuser`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Careapp_customuser` (
  `id` tinyint(4) DEFAULT NULL,
  `password` varchar(88) DEFAULT NULL,
  `last_login` varchar(10) DEFAULT NULL,
  `is_superuser` tinyint(4) DEFAULT NULL,
  `username` varchar(17) DEFAULT NULL,
  `first_name` varchar(0) DEFAULT NULL,
  `last_name` varchar(0) DEFAULT NULL,
  `email` varchar(17) DEFAULT NULL,
  `is_staff` tinyint(4) DEFAULT NULL,
  `is_active` tinyint(4) DEFAULT NULL,
  `date_joined` varchar(10) DEFAULT NULL,
  `userType` varchar(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Careapp_customuser`
--

LOCK TABLES `Careapp_customuser` WRITE;
/*!40000 ALTER TABLE `Careapp_customuser` DISABLE KEYS */;
INSERT INTO `Careapp_customuser` VALUES (1,'pbkdf2_sha256$600000$exAmgPvZeTJv4vDdcEveLb$qUcz9kKgvF9jscxByfsTQxvljQyxm3rFig9rcBmCuBI=','2024-04-02',1,'admin','','','admin@gmail.co',1,1,'2023-07-13',''),(3,'pbkdf2_sha256$600000$18SfbVBoXVKH9wpz0SATm8$XSYBKQlamQaia8vko0fF/BmCXkol5HvqDJnZjWGWykw=','',0,'aswin@gmail.com','','','aswin@gmail.com',0,1,'2023-07-13','worker'),(4,'pbkdf2_sha256$600000$WhvYqXfymkz50liarQk3hk$7We3a110GgkRmd6VzSZBzr7Z5q6SypZAAIu6mKoUVJo=','',0,'abru@gmail.com','','','abru@gmail.com',0,1,'2023-07-13','Senior'),(5,'pbkdf2_sha256$600000$NFPLIEeDFuY2xBWXVshk5F$dFDObCSw7oc5UnXHTZiHKjDqfWWK3RFfkLTSv8mvmTQ=','',0,'ak@mail.com','','','ak@mail.com',0,1,'2023-07-13','Senior'),(6,'pbkdf2_sha256$600000$Ts1Hos3EQZmzKrowz5Cf65$bdBbyUzbwZzZtjj3PiL8fU4iKVV0J3WcLzs8scm+Wto=','',0,'asw@mail.com','','','asw@mail.com',0,1,'2023-07-13','worker'),(7,'pbkdf2_sha256$600000$b54GCmeRjXbfu2KL3gwKSB$BuHLMCz8TEO80mr8ZR5dgX4A2QIZUcT3IFWU/5Wgwqo=','',0,'manu@gmail.com','','','manu@gmail.com',0,1,'2024-04-02','Senior'),(8,'pbkdf2_sha256$600000$rC5B3x8euWNkAuaWGtfKAE$CHgI7rw53EXJzOIL/DIC6I75LHGTzXLGEVzfjdtGWKE=','',0,'vineeth@gmail.com','','','vineeth@gmail.com',0,1,'2024-04-02','Senior');
/*!40000 ALTER TABLE `Careapp_customuser` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Careapp_customuser_groups`
--

DROP TABLE IF EXISTS `Careapp_customuser_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Careapp_customuser_groups` (
  `id` varchar(0) DEFAULT NULL,
  `customuser_id` varchar(0) DEFAULT NULL,
  `group_id` varchar(0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Careapp_customuser_groups`
--

LOCK TABLES `Careapp_customuser_groups` WRITE;
/*!40000 ALTER TABLE `Careapp_customuser_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `Careapp_customuser_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Careapp_customuser_user_permissions`
--

DROP TABLE IF EXISTS `Careapp_customuser_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Careapp_customuser_user_permissions` (
  `id` varchar(0) DEFAULT NULL,
  `customuser_id` varchar(0) DEFAULT NULL,
  `permission_id` varchar(0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Careapp_customuser_user_permissions`
--

LOCK TABLES `Careapp_customuser_user_permissions` WRITE;
/*!40000 ALTER TABLE `Careapp_customuser_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `Careapp_customuser_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Careapp_feedback`
--

DROP TABLE IF EXISTS `Careapp_feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Careapp_feedback` (
  `id` tinyint(4) DEFAULT NULL,
  `feed` varchar(21) DEFAULT NULL,
  `user_id` tinyint(4) DEFAULT NULL,
  `date` varchar(0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Careapp_feedback`
--

LOCK TABLES `Careapp_feedback` WRITE;
/*!40000 ALTER TABLE `Careapp_feedback` DISABLE KEYS */;
INSERT INTO `Careapp_feedback` VALUES (1,'Very good and helpful',1,'');
/*!40000 ALTER TABLE `Careapp_feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Careapp_payment`
--

DROP TABLE IF EXISTS `Careapp_payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Careapp_payment` (
  `id` tinyint(4) DEFAULT NULL,
  `amt` decimal(5,1) DEFAULT NULL,
  `seid_id` tinyint(4) DEFAULT NULL,
  `uid_id` tinyint(4) DEFAULT NULL,
  `date` varchar(0) DEFAULT NULL,
  `com` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Careapp_payment`
--

LOCK TABLES `Careapp_payment` WRITE;
/*!40000 ALTER TABLE `Careapp_payment` DISABLE KEYS */;
INSERT INTO `Careapp_payment` VALUES (1,1200.0,1,1,'',''),(2,1200.0,1,1,'',''),(3,1200.0,1,1,'',''),(4,1200.0,1,1,'',''),(5,1200.0,1,1,'',''),(6,1200.0,1,1,'',''),(7,1200.0,1,1,'',''),(8,1200.0,1,1,'',''),(9,1200.0,1,1,'',''),(10,1200.0,1,1,'',''),(11,1080.0,2,1,'','120.0'),(12,1080.0,4,1,'','120.0');
/*!40000 ALTER TABLE `Careapp_payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Careapp_rate`
--

DROP TABLE IF EXISTS `Careapp_rate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Careapp_rate` (
  `id` tinyint(4) DEFAULT NULL,
  `rating` decimal(2,1) DEFAULT NULL,
  `uid_id` tinyint(4) DEFAULT NULL,
  `wid_id` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Careapp_rate`
--

LOCK TABLES `Careapp_rate` WRITE;
/*!40000 ALTER TABLE `Careapp_rate` DISABLE KEYS */;
INSERT INTO `Careapp_rate` VALUES (1,3.5,1,2),(2,4.0,1,2),(3,2.5,1,2),(4,4.0,1,2);
/*!40000 ALTER TABLE `Careapp_rate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Careapp_registration`
--

DROP TABLE IF EXISTS `Careapp_registration`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Careapp_registration` (
  `id` tinyint(4) DEFAULT NULL,
  `name` varchar(7) DEFAULT NULL,
  `email` varchar(17) DEFAULT NULL,
  `add` varchar(12) DEFAULT NULL,
  `con` bigint(20) DEFAULT NULL,
  `psw` varchar(11) DEFAULT NULL,
  `user_id` tinyint(4) DEFAULT NULL,
  `aadhaar` varchar(14) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Careapp_registration`
--

LOCK TABLES `Careapp_registration` WRITE;
/*!40000 ALTER TABLE `Careapp_registration` DISABLE KEYS */;
INSERT INTO `Careapp_registration` VALUES (1,'abru','abru@gmail.com','Home',7777777777,'Abru@123',4,'2544 8521 5698'),(2,'ak','ak@mail.com','Home',7777777777,'Ak@12345',5,'3265 9865 5487'),(3,'Manu','manu@gmail.com','Test Address',8965321254,'Manu@123',7,'5421 8754 7854'),(4,'Vineeth','vineeth@gmail.com','Idukki',8965321254,'Vineeth@123',8,'4578 2165 9878');
/*!40000 ALTER TABLE `Careapp_registration` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Careapp_service`
--

DROP TABLE IF EXISTS `Careapp_service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Careapp_service` (
  `id` tinyint(4) DEFAULT NULL,
  `title` varchar(14) DEFAULT NULL,
  `desc` varchar(47) DEFAULT NULL,
  `amount` smallint(6) DEFAULT NULL,
  `workingTime` varchar(15) DEFAULT NULL,
  `wid_id` varchar(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Careapp_service`
--

LOCK TABLES `Careapp_service` WRITE;
/*!40000 ALTER TABLE `Careapp_service` DISABLE KEYS */;
INSERT INTO `Careapp_service` VALUES (1,'House Cleaning','Im a skilled house cleaner and maintenance',1200,'Mon-Sat 9 hours',''),(2,'House Cleaning','I am  a professional house maintaining cleaner.',1200,'Mon-Sun 6 hours','2'),(3,'Cleaning','Available from 9 AM - 5PM',800,'2 Hour Per Day','3');
/*!40000 ALTER TABLE `Careapp_service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Careapp_servicebook`
--

DROP TABLE IF EXISTS `Careapp_servicebook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Careapp_servicebook` (
  `id` tinyint(4) DEFAULT NULL,
  `bdate` varchar(0) DEFAULT NULL,
  `status` varchar(9) DEFAULT NULL,
  `info` varchar(18) DEFAULT NULL,
  `sid_id` tinyint(4) DEFAULT NULL,
  `user_id` tinyint(4) DEFAULT NULL,
  `date` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Careapp_servicebook`
--

LOCK TABLES `Careapp_servicebook` WRITE;
/*!40000 ALTER TABLE `Careapp_servicebook` DISABLE KEYS */;
INSERT INTO `Careapp_servicebook` VALUES (1,'','Paid','PLease i need help',2,1,'2023-07-13'),(2,'','Paid','Thank you',2,1,'2023-07-13'),(3,'','Completed','aaaa',2,1,'2023-07-20'),(4,'','Paid','hi',2,1,'2023-07-20'),(5,'','Completed','i need help',2,1,'2023-07-22');
/*!40000 ALTER TABLE `Careapp_servicebook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Careapp_worker`
--

DROP TABLE IF EXISTS `Careapp_worker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Careapp_worker` (
  `id` tinyint(4) DEFAULT NULL,
  `name` varchar(5) DEFAULT NULL,
  `email` varchar(15) DEFAULT NULL,
  `add` varchar(4) DEFAULT NULL,
  `con` bigint(20) DEFAULT NULL,
  `psw` varchar(9) DEFAULT NULL,
  `lic` varchar(32) DEFAULT NULL,
  `cat_id` tinyint(4) DEFAULT NULL,
  `user_id` tinyint(4) DEFAULT NULL,
  `lat` decimal(7,5) DEFAULT NULL,
  `lon` decimal(7,5) DEFAULT NULL,
  `rating` decimal(2,1) DEFAULT NULL,
  `status` varchar(9) DEFAULT NULL,
  `prof` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Careapp_worker`
--

LOCK TABLES `Careapp_worker` WRITE;
/*!40000 ALTER TABLE `Careapp_worker` DISABLE KEYS */;
INSERT INTO `Careapp_worker` VALUES (2,'Aswin','aswin@gmail.com','Home',7777777777,'Aswin@123','pexels-anamul-rezwan-1145434.jpg',2,3,10.11033,76.34932,3.5,'Available','pexels-anamul-rezwan-1145434_zugNvkw.jpg'),(3,'Aswin','asw@mail.com','Home',7777777777,'Aswin@123','pexels-pixabay-45842.jpg',2,6,10.11033,76.34932,0.0,'Available','pexels-pixabay-33786.jpg');
/*!40000 ALTER TABLE `Careapp_worker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` varchar(0) DEFAULT NULL,
  `name` varchar(0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` varchar(0) DEFAULT NULL,
  `group_id` varchar(0) DEFAULT NULL,
  `permission_id` varchar(0) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` tinyint(4) DEFAULT NULL,
  `content_type_id` tinyint(4) DEFAULT NULL,
  `codename` varchar(19) DEFAULT NULL,
  `name` varchar(23) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,1,'add_logentry','Can add log entry'),(2,1,'change_logentry','Can change log entry'),(3,1,'delete_logentry','Can delete log entry'),(4,1,'view_logentry','Can view log entry'),(5,2,'add_permission','Can add permission'),(6,2,'change_permission','Can change permission'),(7,2,'delete_permission','Can delete permission'),(8,2,'view_permission','Can view permission'),(9,3,'add_group','Can add group'),(10,3,'change_group','Can change group'),(11,3,'delete_group','Can delete group'),(12,3,'view_group','Can view group'),(13,4,'add_contenttype','Can add content type'),(14,4,'change_contenttype','Can change content type'),(15,4,'delete_contenttype','Can delete content type'),(16,4,'view_contenttype','Can view content type'),(17,5,'add_session','Can add session'),(18,5,'change_session','Can change session'),(19,5,'delete_session','Can delete session'),(20,5,'view_session','Can view session'),(21,6,'add_category','Can add category'),(22,6,'change_category','Can change category'),(23,6,'delete_category','Can delete category'),(24,6,'view_category','Can view category'),(25,7,'add_chat','Can add chat'),(26,7,'change_chat','Can change chat'),(27,7,'delete_chat','Can delete chat'),(28,7,'view_chat','Can view chat'),(29,8,'add_registration','Can add registration'),(30,8,'change_registration','Can change registration'),(31,8,'delete_registration','Can delete registration'),(32,8,'view_registration','Can view registration'),(33,9,'add_service','Can add service'),(34,9,'change_service','Can change service'),(35,9,'delete_service','Can delete service'),(36,9,'view_service','Can view service'),(37,10,'add_customuser','Can add user'),(38,10,'change_customuser','Can change user'),(39,10,'delete_customuser','Can delete user'),(40,10,'view_customuser','Can view user'),(41,11,'add_worker','Can add worker'),(42,11,'change_worker','Can change worker'),(43,11,'delete_worker','Can delete worker'),(44,11,'view_worker','Can view worker'),(45,12,'add_servicebook','Can add servicebook'),(46,12,'change_servicebook','Can change servicebook'),(47,12,'delete_servicebook','Can delete servicebook'),(48,12,'view_servicebook','Can view servicebook'),(49,13,'add_payment','Can add payment'),(50,13,'change_payment','Can change payment'),(51,13,'delete_payment','Can delete payment'),(52,13,'view_payment','Can view payment'),(53,14,'add_feedback','Can add feedback'),(54,14,'change_feedback','Can change feedback'),(55,14,'delete_feedback','Can delete feedback'),(56,14,'view_feedback','Can view feedback'),(57,15,'add_requests','Can add requests'),(58,15,'change_requests','Can change requests'),(59,15,'delete_requests','Can delete requests'),(60,15,'view_requests','Can view requests'),(61,16,'add_rate','Can add rate'),(62,16,'change_rate','Can change rate'),(63,16,'delete_rate','Can delete rate'),(64,16,'view_rate','Can view rate'),(65,17,'add_commission','Can add commission'),(66,17,'change_commission','Can change commission'),(67,17,'delete_commission','Can delete commission'),(68,17,'view_commission','Can view commission');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` tinyint(4) DEFAULT NULL,
  `object_id` tinyint(4) DEFAULT NULL,
  `object_repr` varchar(23) DEFAULT NULL,
  `action_flag` tinyint(4) DEFAULT NULL,
  `change_message` varchar(38) DEFAULT NULL,
  `content_type_id` tinyint(4) DEFAULT NULL,
  `user_id` tinyint(4) DEFAULT NULL,
  `action_time` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,1,'Servicebook object (1)',2,'[{\"changed\": {\"fields\": [\"Bdate\"]}}]',12,1,'2023-07-13'),(2,2,'Worker object (2)',2,'[{\"changed\": {\"fields\": [\"Status\"]}}]',11,1,'2023-07-13'),(3,2,'Worker object (2)',2,'[{\"changed\": {\"fields\": [\"Status\"]}}]',11,1,'2023-07-13'),(4,3,'Registration object (3)',2,'[{\"changed\": {\"fields\": [\"Aadhaar\"]}}]',8,1,'2024-04-02'),(5,2,'Registration object (2)',2,'[{\"changed\": {\"fields\": [\"Aadhaar\"]}}]',8,1,'2024-04-02'),(6,1,'Registration object (1)',2,'[{\"changed\": {\"fields\": [\"Aadhaar\"]}}]',8,1,'2024-04-02');
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` tinyint(4) DEFAULT NULL,
  `app_label` varchar(12) DEFAULT NULL,
  `model` varchar(12) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (6,'Careapp','category'),(7,'Careapp','chat'),(17,'Careapp','commission'),(10,'Careapp','customuser'),(14,'Careapp','feedback'),(13,'Careapp','payment'),(16,'Careapp','rate'),(8,'Careapp','registration'),(15,'Careapp','requests'),(9,'Careapp','service'),(12,'Careapp','servicebook'),(11,'Careapp','worker'),(1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(4,'contenttypes','contenttype'),(5,'sessions','session');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_migrations` (
  `id` tinyint(4) DEFAULT NULL,
  `app` varchar(12) DEFAULT NULL,
  `name` varchar(46) DEFAULT NULL,
  `applied` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2023-07-13'),(2,'contenttypes','0002_remove_content_type_name','2023-07-13'),(3,'auth','0001_initial','2023-07-13'),(4,'auth','0002_alter_permission_name_max_length','2023-07-13'),(5,'auth','0003_alter_user_email_max_length','2023-07-13'),(6,'auth','0004_alter_user_username_opts','2023-07-13'),(7,'auth','0005_alter_user_last_login_null','2023-07-13'),(8,'auth','0006_require_contenttypes_0002','2023-07-13'),(9,'auth','0007_alter_validators_add_error_messages','2023-07-13'),(10,'auth','0008_alter_user_username_max_length','2023-07-13'),(11,'auth','0009_alter_user_last_name_max_length','2023-07-13'),(12,'auth','0010_alter_group_name_max_length','2023-07-13'),(13,'auth','0011_update_proxy_permissions','2023-07-13'),(14,'auth','0012_alter_user_first_name_max_length','2023-07-13'),(15,'Careapp','0001_initial','2023-07-13'),(16,'admin','0001_initial','2023-07-13'),(17,'admin','0002_logentry_remove_auto_add','2023-07-13'),(18,'admin','0003_logentry_add_action_flag_choices','2023-07-13'),(19,'sessions','0001_initial','2023-07-13'),(20,'Careapp','0002_rename_usertype_customuser_usertype','2023-07-13'),(21,'Careapp','0003_requests','2023-07-13'),(22,'Careapp','0004_worker_rating_worker_status','2023-07-13'),(23,'Careapp','0005_worker_lat_worker_lon','2023-07-13'),(24,'Careapp','0006_remove_worker_rating_remove_worker_status','2023-07-13'),(25,'Careapp','0007_worker_rating_worker_status','2023-07-13'),(26,'Careapp','0008_worker_prof','2023-07-13'),(27,'Careapp','0009_alter_servicebook_date','2023-07-13'),(28,'Careapp','0010_alter_payment_date','2023-07-13'),(29,'Careapp','0011_feedback_date_delete_requests','2023-07-13'),(30,'Careapp','0012_rate','2023-07-13'),(31,'Careapp','0013_payment_com_commission','2023-07-20'),(32,'Careapp','0014_registration_aadhaar','2024-04-02');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(32) DEFAULT NULL,
  `session_data` varchar(227) DEFAULT NULL,
  `expire_date` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('gtdr2xnrhv4mlob07c60nbtyo3xe7q98','eyJlbWFpbCI6ImFkbWluIn0:1qJqoy:7y8cDKcyYIuqxTRQvEbkQhyVtgS2yOeqmPmxrwu5aY8','2023-07-27'),('i0tr0fp7iif8obk5ngtjh53jh8ajbw5j','eyJlbWFpbCI6ImFicnVAZ21haWwuY29tIiwiaWQiOjIsIm5hbWUiOiJhc3dpbiJ9:1qJuHC:Xx8Tt9cXim23siChgQeihUeK9MiwZyP5swU3sSuMwJw','2023-07-27'),('eng3r79x12hr6fk6y4mhnj8ttmcuzzq9','eyJlbWFpbCI6ImFicnVAZ21haWwuY29tIiwiaWQiOjEsIm5hbWUiOiJhYnJ1In0:1qJwEB:Sl2JSNB0RLUQZG_xeGREjrumuAlPN0eQ4y1ADDH5cA4','2023-07-27'),('6d4kzuok8yketraeiy1mif1nakfxhah6','eyJlbWFpbCI6ImFkbWluIiwiaWQiOjEsIm5hbWUiOiJhYnJ1In0:1qJxzn:9JHavg5jpLdee-tpgJIo0TfSP22OUK272bklQ_IlshM','2023-07-27'),('j4h7vkv43qtp88nii62njyvmc26wb3l3','eyJlbWFpbCI6ImFzd2luQGdtYWlsLmNvbSIsImlkIjoyLCJuYW1lIjoiQXN3aW4ifQ:1qJyH3:eHfEO8Fq9pRBouMzL7S_pI_Y0NBoXDxPUb3M71OSKto','2023-07-27'),('58036fpk95o0p48e200spjbo15kc5wii','eyJlbWFpbCI6ImFicnVAZ21haWwuY29tIiwiaWQiOjEsIm5hbWUiOiJhYnJ1In0:1qK12V:2KO1AyNLOO2543c8ViQI8FzOo3AN-veZVga37NUJ42o','2023-07-27'),('0yzt7fj9ox0upksfi5ex1jm75v77ldo0','eyJlbWFpbCI6ImFkbWluIn0:1qK482:vg4jqgtZwa6uHMQMJxbULlYc7k-pzwpSMHJwN2GIW80','2023-07-27'),('0bfyq4q0d2khoja3a7xykorb5d80npwb','eyJlbWFpbCI6ImFicnVAZ21haWwuY29tIiwiaWQiOjEsIm5hbWUiOiJhYnJ1In0:1qK4al:rf8kM3nhdvIURS_nP5IswSiYHle8EsRoYvaF8qjUhtg','2023-07-27'),('j3ce3kmp6ncf95413mftdh7gn0546x89','eyJlbWFpbCI6ImFzd2luQGdtYWlsLmNvbSIsImlkIjoyLCJuYW1lIjoiQXN3aW4ifQ:1qKAvD:u7faMcw7Wgntv13Lp3o89SB00srBRHSXN-0r2yIEzFk','2023-07-28'),('cazc2yk1ao2huacutkb1sos2wr78svsd','eyJlbWFpbCI6ImFicnVAZ21haWwuY29tIiwiaWQiOjEsIm5hbWUiOiJhYnJ1In0:1qKBpr:wD3Ceb8jpJ0-LhJGRrPrmwpMtttSi0KQm6Bk1V6VZ4w','2023-07-28'),('ndiifufwf90rjt40r2q2ua2tpdxcsfwh','eyJlbWFpbCI6ImFkbWluIn0:1qKEJu:y9j9PwN2I7cmO5lwVbRy4wj-KjSODJl4ydGP0bxB2es','2023-07-28'),('jp7c60uui5xx7534mta6uw1b9rkvqyvg','eyJlbWFpbCI6ImFicnVAZ21haWwuY29tIiwiaWQiOjEsIm5hbWUiOiJhYnJ1In0:1qLcCy:jSAKpiyDYNmFDlhs1GYQ0slMZX1T6_YANL0laFpZSXE','2023-08-01'),('nkmwrnqk3e81fj17muzegi86pan2cm1o','eyJlbWFpbCI6ImFkbWluIn0:1qLjel:w1OiA3foJ0k9IPzwQ0K5D8edNILalGp9_bu5nK6NpwE','2023-08-01'),('id9127x2lvh4s2e9nq3bmynsbmmi4mug','eyJlbWFpbCI6ImFkbWluIiwiaWQiOjEsIm5hbWUiOiJhYnJ1In0:1qMQl4:YCM9cnrKiwMKIOizOVxk57NrHRabLIf72oA06E-D3s0','2023-08-03'),('4b714lk8mxhrvlv7tobqi8awcilvnicc','eyJlbWFpbCI6ImFzd2luQGdtYWlsLmNvbSIsImlkIjoyLCJuYW1lIjoiQXN3aW4ifQ:1qMXe6:-YSPyieOYUruc46Jz1r2JyXQ1U6ztKXfl30IBt0QNkA','2023-08-03'),('h0w09m2pmitdsj2hf04gwnlqjnx26o28','eyJlbWFpbCI6ImFicnVAZ21haWwuY29tIiwiaWQiOjEsIm5hbWUiOiJhYnJ1In0:1qN5vw:Huq2o1Y5m7lkwCJGLiEL_7Qyb2qfvl9zHT-zw8RIVgM','2023-08-05'),('3u3adw778g5ihb3393tgeu8srucvf995','eyJlbWFpbCI6ImFkbWluIiwiaWQiOjEsIm5hbWUiOiJhYnJ1In0:1rhsxj:dMRXq4cNlMxxD8HyKAJw3Z5F4pGhZADMze9l0yxkzT8','2024-03-20'),('qi1krgfy6lyk0ar79sbywug41zxvvyrl','eyJlbWFpbCI6ImFicnVAZ21haWwuY29tIiwiaWQiOjEsIm5hbWUiOiJhYnJ1In0:1ripIv:qTZA-Y_a3Hjv63gCaQMlg17mCi4iRmZAcPnNBxM2QuE','2024-03-23'),('j59qp21lpiw1sd3x4t3nvo1gklriwfqd','.eJxVjEEOwiAQRe_C2hBxYACX7j0DmWGoVA1NSrsy3l2bdKHb_977L5VoXWpae5nTKOqsjDr8bkz5UdoG5E7tNuk8tWUeWW-K3mnX10nK87K7fweVev3WgBTBordIBUHMiZCJIYiUaO0gR1cwmuBzcIADUyQfLIIXMsDeGfX-ANhSN4M:1rrgLd:fjz6MqVvNlJtaqCbGzuEHMtZXXdjfK9wMrdDZoPJr2k','2024-04-16'),('wn4zhu125hctqm12jjluui7uatsk0uif','eyJlbWFpbCI6ImFicnVAZ21haWwuY29tIiwiaWQiOjEsIm5hbWUiOiJhYnJ1In0:1rsxFX:Mr6wJSQqtRMNSDBOOYu2qLfdiui-NJIf0fzNYv24c8w','2024-04-20');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sqlite_sequence`
--

DROP TABLE IF EXISTS `sqlite_sequence`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sqlite_sequence` (
  `name` varchar(20) DEFAULT NULL,
  `seq` tinyint(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sqlite_sequence`
--

LOCK TABLES `sqlite_sequence` WRITE;
/*!40000 ALTER TABLE `sqlite_sequence` DISABLE KEYS */;
INSERT INTO `sqlite_sequence` VALUES ('django_migrations',32),('django_content_type',17),('auth_permission',68),('auth_group',0),('django_admin_log',6),('Careapp_customuser',8),('Careapp_category',5),('Careapp_worker',3),('Careapp_service',3),('Careapp_registration',4),('Careapp_servicebook',5),('Careapp_payment',12),('Careapp_chat',3),('Careapp_feedback',1),('Careapp_rate',4),('Careapp_commission',2);
/*!40000 ALTER TABLE `sqlite_sequence` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-11 11:57:18
